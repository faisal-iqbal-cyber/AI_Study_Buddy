// firebase.js
import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyBA5LgWpnsJIfNUAy0XY9CwEfe8FWY_QFQ",
  authDomain: "aistudybuddy-14b3e.firebaseapp.com",
  databaseURL: "https://aistudybuddy-14b3e-default-rtdb.firebaseio.com/",
  projectId: "aistudybuddy-14b3e",
  storageBucket: "aistudybuddy-14b3e.appspot.com",
  messagingSenderId: "917455809747",
  appId: "YOUR_APP_ID" // 👈 Optional: Add this from Firebase Console (explained below)
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

export { app, db };

