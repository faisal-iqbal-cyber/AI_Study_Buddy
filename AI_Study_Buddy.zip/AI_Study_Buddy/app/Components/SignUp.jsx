import { FontAwesome, MaterialIcons } from '@expo/vector-icons';
import React, { useState } from 'react';
import { Modal, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

export default function SignUp({ navigation }) {
  const [modalVisible, setModalVisible] = useState(false);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [confirmPasswordVisible, setConfirmPasswordVisible] = useState(false);

  async function handleSignUp() {
    if (!email || !name || !password || !confirmPassword) {
      setError('Please fill out all required fields.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('Please enter a valid email address (e.g., abc@example.com).');
      return;
    }

    if (password !== confirmPassword) {
      setError('Password and Confirm Password must be the same.');
      return;
    }

    try {
      // Step 1: Sign up with Firebase Authentication
      const response = await fetch(
        'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyBA5LgWpnsJIfNUAy0XY9CwEfe8FWY_QFQ',
        {
          method: 'POST',
          headers: {
            Accept: 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: email,
            password: password,
            returnSecureToken: true,
          }),
        }
      );

      const result = await response.json();
      if (result.error) {
        setError(result.error.message || 'Signup failed. Please check your API key restrictions or enable reCAPTCHA.');
        return;
      }

      const firebaseUserID = result.localId;

      // Step 2: Store additional data in Realtime Database
      const userData = {
        name: name,
        email: email,
      };

      await fetch(`https://aistudybuddy-14b3e-default-rtdb.firebaseio.com/users/${firebaseUserID}.json`, {
        method: 'PUT',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });

      setError('');
      setModalVisible(true);
      console.log('SignUp: Navigating to DashboardScreen with userID:', firebaseUserID);
      setTimeout(() => {
        setModalVisible(false);
        navigation.navigate('DashboardScreen', { userID: firebaseUserID });
      }, 2000);
    } catch (err) {
      console.error('Signup error:', err);
      setError('Something went wrong. Please try again or check your Firebase configuration.');
    }
  }

  return (
    <View style={styles.wrapper}>
      <Modal animationType="slide" visible={modalVisible} transparent={true}>
        <View style={styles.centeredDiv}>
          <View style={styles.modalView}>
            <Text style={{ marginBottom: 10, fontSize: 17 }}>Signup Successfully</Text>
            <TouchableOpacity
              style={styles.modalCloseButton}
              onPress={() => {
                setModalVisible(false);
                navigation.navigate('DashboardScreen');
              }}
            >
              <Text style={{ color: '#112f91', marginLeft: 30, fontSize: 16 }}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Text style={styles.logo}>
          <Text style={styles.logoMini}>Study</Text>
          <Text style={styles.logoMain}>Buddy</Text>
        </Text>

        <View style={styles.separator} />

        <Text style={styles.heading}>Sign Up</Text>
        <Text style={styles.subHeading}>Personal Info</Text>
        <Text style={styles.note}>
          Your information will be kept private
        </Text>

        <View style={styles.inputContainer}>
          <FontAwesome name="user" size={20} color="#666" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Full Name"
            value={name}
            maxLength={30}
            onChangeText={setName}
          />
        </View>

        <View style={styles.inputContainer}>
          <MaterialIcons name="email" size={20} color="#666" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Email (abc@example.com)"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        <View style={styles.inputContainer}>
          <MaterialIcons name="lock" size={20} color="#666" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Password"
            secureTextEntry={!passwordVisible}
            value={password}
            maxLength={8}
            onChangeText={setPassword}
          />
          <TouchableOpacity onPress={() => setPasswordVisible(!passwordVisible)}>
            <MaterialIcons
              name={passwordVisible ? 'visibility' : 'visibility-off'}
              size={20}
              color="#666"
            />
          </TouchableOpacity>
        </View>

        <View style={styles.inputContainer}>
          <MaterialIcons name="lock" size={20} color="#666" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Confirm Password"
            secureTextEntry={!confirmPasswordVisible}
            value={confirmPassword}
            maxLength={8}
            onChangeText={setConfirmPassword}
          />
          <TouchableOpacity onPress={() => setConfirmPasswordVisible(!confirmPasswordVisible)}>
            <MaterialIcons
              name={confirmPasswordVisible ? 'visibility' : 'visibility-off'}
              size={20}
              color="#666"
            />
          </TouchableOpacity>
        </View>
      </ScrollView>

      <View style={styles.fixedBottom}>
        {error !== '' && <Text style={styles.errorText}>{error}</Text>}

        <TouchableOpacity style={styles.confirmButton} onPress={handleSignUp}>
          <Text style={styles.confirmText}>CONFIRM</Text>
          <Text style={styles.arrow}>➔</Text>
        </TouchableOpacity>

        <TouchableOpacity>
          <Text style={styles.loginText} onPress={() => navigation.navigate('Login')}>
            Login
          </Text>
        </TouchableOpacity>

        <TouchableOpacity>
          <Text
            style={styles.forgotText}
            onPress={() => navigation.navigate('ForgotPassword')}
          >
            Forgot Password
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    backgroundColor: '#fff',
  },
  scrollContainer: {
    padding: 20,
    paddingBottom: 20,
  },
  fixedBottom: {
    paddingHorizontal: 20,
    paddingBottom: 70,
    backgroundColor: '#fff',
  },
  logo: {
    fontSize: 26,
    textAlign: 'center',
    marginBottom: 10,
  },
  logoMini: {
    fontSize: 16,
    color: '#333',
    fontWeight: 'bold',
  },
  logoMain: {
    fontSize: 27,
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  separator: {
    borderBottomColor: '#999',
    borderBottomWidth: 1,
    marginBottom: 20,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#4CAF50',
  },
  subHeading: {
    fontSize: 17,
    fontWeight: 'bold',
    marginTop: 10,
    textAlign: 'center',
    marginBottom: 10,
  },
  note: {
    fontSize: 12,
    color: '#555',
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    borderRadius: 10,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  icon: {
    marginRight: 10,
  },
  input: {
    flex: 1,
    height: 40,
    fontSize: 14,
  },
  confirmButton: {
    flexDirection: 'row',
    backgroundColor: '#FFA500',
    paddingVertical: 9,
    paddingHorizontal: 20,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  confirmText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  arrow: {
    fontSize: 20,
    color: '#fff',
  },
  loginText: {
    textAlign: 'center',
    color: 'blue',
    marginTop: 20,
    fontSize: 19,
    textDecorationLine: 'underline',
  },
  forgotText: {
    textAlign: 'center',
    color: 'red',
    marginTop: 10,
    fontSize: 18,
    textDecorationLine: 'underline',
  },
  errorText: {
    color: 'red',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 10,
  },
  centeredDiv: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalView: {
    margin: 20,
    backgroundColor: 'white',
    borderRadius: 8,
    justifyContent: 'center',
    alignContent: 'center',
    paddingTop: 27,
    paddingBottom: 15,
    paddingLeft: 25,
    paddingRight: 25,
  },
  modalCloseButton: {
    padding: 10,
    marginLeft: 15,
  },
});