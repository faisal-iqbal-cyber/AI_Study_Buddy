import { FontAwesome } from '@expo/vector-icons';
import Voice from '@react-native-voice/voice';
import axios from 'axios';
import * as ImagePicker from 'expo-image-picker';
import { child, get, push, ref } from 'firebase/database';
import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  PermissionsAndroid,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { db } from '../../firebase';

export default function DashboardScreen({ route }) {
  const { userID } = route.params;
  const [userName, setUserName] = useState('');
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [isRecording, setIsRecording] = useState(false);

  const openaiKey = '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'; // Your OpenRouter key

  useEffect(() => {
    const fetchUserName = async () => {
      try {
        const snapshot = await get(child(ref(db), `users/${userID}`));
        if (snapshot.exists()) {
          const data = snapshot.val();
          setUserName(data.name || 'User');
        }
      } catch (err) {
        console.log('Error fetching user name:', err);
      }
    };
    fetchUserName();

    // Initialize voice recognition
    Voice.onSpeechStart = () => setIsRecording(true);
    Voice.onSpeechEnd = () => setIsRecording(false);
    Voice.onSpeechError = (err) => {
      console.log('Voice error:', err);
      setIsRecording(false);
      setAnswer('⚠️ Voice recognition error. Please try again.');
    };
    Voice.onSpeechResults = (e) => {
      if (e.value && e.value.length > 0) {
        setQuestion(e.value[0]);
      }
    };

    return () => {
      Voice.destroy().then(Voice.removeAllListeners);
    };
  }, []);

  const requestMicrophonePermission = async () => {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
          {
            title: 'Microphone Permission',
            message: 'AI Study Buddy needs access to your microphone to enable voice input.',
            buttonPositive: 'OK',
            buttonNegative: 'Cancel',
          }
        );
        return granted === PermissionsAndroid.RESULTS.GRANTED;
      } catch (err) {
        console.warn('Permission error:', err);
        return false;
      }
    }
    return true; // iOS handles permissions automatically via Voice
  };

  const handleVoiceInput = async () => {
    if (isRecording) {
      try {
        await Voice.stop();
        setIsRecording(false);
      } catch (err) {
        console.log('Voice stop error:', err);
      }
      return;
    }

    const hasPermission = await requestMicrophonePermission();
    if (!hasPermission) {
      setAnswer('⚠️ Microphone permission denied. Please enable it in settings.');
      return;
    }

    try {
      await Voice.start('en-US');
    } catch (err) {
      console.log('Voice start error:', err);
      setAnswer('⚠️ Error starting voice recognition. Please try again.');
    }
  };

  const askQuestion = async () => {
    if (!question.trim()) return;
    const currentQuestion = question;
    setLoading(true);
    setQuestion('');
    setAnswer('');

    try {
      const response = await axios.post(
        'https://openrouter.ai/api/v1/chat/completions',
        {
          model: 'mistralai/mistral-7b-instruct',
          messages: [{ role: 'user', content: currentQuestion }],
        },
        {
          headers: {
            'Authorization': `Bearer ${openaiKey}`,
            'Content-Type': 'application/json',
            'HTTP-Referer': 'https://yourapp.com',
          },
        }
      );

      const aiAnswer = response.data.choices[0].message.content.trim();
      setAnswer(aiAnswer);

      const qna = {
        question: currentQuestion,
        answer: aiAnswer,
        timestamp: new Date().toISOString(),
      };

      setChatHistory((prev) => [...prev, qna]);
      await push(ref(db, `qnaHistory/${userID}`), qna);
    } catch (err) {
      console.log('OpenRouter API error:', err?.response?.data || err);
      setAnswer('⚠️ Error fetching AI response. Please try again.');
    }

    setLoading(false);
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
      base64: true,
    });

    if (!result.canceled) {
      setSelectedImage(result.assets[0].uri);
      setAnswer('🧠 Image uploaded.\nImage understanding requires GPT-4 Vision, which is not available on free plan.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>
        Hi, <Text style={styles.userName}>{userName}</Text> 👋
      </Text>
      <Text style={styles.subtext}>Ask anything, like "Explain gravity"</Text>

      <ScrollView style={styles.chatBox}>
        {chatHistory.map((item, index) => (
          <View key={index} style={styles.chatItem}>
            <View style={styles.userBubble}>
              <Text style={styles.userLabel}>You</Text>
              <Text style={styles.userText}>{item.question}</Text>
            </View>
            <View style={styles.aiBubble}>
              <Text style={styles.aiLabel}>AI</Text>
              <Text style={styles.aiText}>{item.answer}</Text>
            </View>
          </View>
        ))}
        {loading && <ActivityIndicator size="large" color="#007BFF" style={{ marginTop: 20 }} />}
      </ScrollView>

      {selectedImage && (
        <Image source={{ uri: selectedImage }} style={styles.previewImage} resizeMode="contain" />
      )}

      <TextInput
        placeholder="Type your question here..."
        value={question}
        onChangeText={setQuestion}
        style={styles.input}
        multiline
      />

      <View style={styles.buttonRow}>
        <TouchableOpacity style={styles.button} onPress={askQuestion}>
          <FontAwesome name="send" size={20} color="#fff" />
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, isRecording ? styles.recordingButton : null]}
          onPress={handleVoiceInput}
        >
          <FontAwesome
            name={isRecording ? 'stop' : 'microphone'}
            size={20}
            color="#fff"
          />
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={pickImage}>
          <FontAwesome name="image" size={20} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f7fb',
    paddingHorizontal: 16,
    paddingTop: 40,
  },
  header: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1F2937',
  },
  userName: {
    color: '#007BFF',
  },
  subtext: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 16,
  },
  chatBox: {
    flex: 1,
    marginBottom: 10,
  },
  chatItem: {
    marginBottom: 16,
  },
  userBubble: {
    alignSelf: 'flex-end',
    backgroundColor: '#DCF8C6',
    padding: 12,
    borderRadius: 10,
    maxWidth: '85%',
  },
  aiBubble: {
    alignSelf: 'flex-start',
    backgroundColor: '#E5E7EB',
    padding: 12,
    borderRadius: 10,
    maxWidth: '85%',
    marginTop: 6,
  },
  userLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#2563EB',
  },
  aiLabel: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#6B7280',
  },
  userText: {
    fontSize: 15,
    color: '#111827',
    marginTop: 2,
  },
  aiText: {
    fontSize: 15,
    color: '#374151',
    marginTop: 2,
  },
  input: {
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 14,
    fontSize: 15,
    borderWidth: 1,
    borderColor: '#ccc',
    minHeight: 50,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 12,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    marginHorizontal: 4,
  },
  recordingButton: {
    backgroundColor: '#FF4D4F', // Red when recording
  },
  previewImage: {
    width: '100%',
    height: 140,
    marginVertical: 10,
    borderRadius: 12,
  },
});