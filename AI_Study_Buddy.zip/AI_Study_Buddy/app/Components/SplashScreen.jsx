import React, { useEffect, useRef } from 'react';
import { Animated, StyleSheet, Text, View } from 'react-native';

const SplashScreen = ({ navigation }) => {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 3,
        useNativeDriver: true,
      }),
    ]).start();

    const timer = setTimeout(() => {
      navigation.replace('SignUp');
    }, 5000);

    return () => clearTimeout(timer);
  }, [fadeAnim, scaleAnim, navigation]);

  return (
    <View style={styles.container}>
      <Animated.View
        style={{
          opacity: fadeAnim,
          transform: [{ scale: scaleAnim }],
          alignItems: 'center',
        }}
      >
        <View style={styles.textContainer}>
          <Text style={styles.asaanText}>Study</Text>
          <Text style={styles.kaamText}>Buddy</Text>
        </View>
        <View style={styles.separator} />

        <Text style={styles.tagline}>Proving Helpful in Study</Text>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5', // Off-white background
    marginBottom: 40,
  },
  textContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginTop: -60,
  },
  asaanText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#000',
    marginRight: -5,
    marginBottom: 5,
    textShadowColor: 'rgba(0, 0, 0, 0.2)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 2,
  },
  kaamText: {
    fontSize: 50,
    fontWeight: 'bold',
    color: '#008000',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 2,
  },
  tagline: {
    fontSize: 16,
    color: '#003087', // Deep blue color
    marginTop: 0,
    fontStyle: 'italic',
  },
});

export default SplashScreen;