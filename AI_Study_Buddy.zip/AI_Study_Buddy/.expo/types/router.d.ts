/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/Components/DashboardScreen`; params?: Router.UnknownInputParams; } | { pathname: `/Components/ForgotPassword`; params?: Router.UnknownInputParams; } | { pathname: `/Components/Login`; params?: Router.UnknownInputParams; } | { pathname: `/Components/SignUp`; params?: Router.UnknownInputParams; } | { pathname: `/Components/SplashScreen`; params?: Router.UnknownInputParams; };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/`; params?: Router.UnknownOutputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; } | { pathname: `/Components/DashboardScreen`; params?: Router.UnknownOutputParams; } | { pathname: `/Components/ForgotPassword`; params?: Router.UnknownOutputParams; } | { pathname: `/Components/Login`; params?: Router.UnknownOutputParams; } | { pathname: `/Components/SignUp`; params?: Router.UnknownOutputParams; } | { pathname: `/Components/SplashScreen`; params?: Router.UnknownOutputParams; };
      href: Router.RelativePathString | Router.ExternalPathString | `/${`?${string}` | `#${string}` | ''}` | `/_sitemap${`?${string}` | `#${string}` | ''}` | `/Components/DashboardScreen${`?${string}` | `#${string}` | ''}` | `/Components/ForgotPassword${`?${string}` | `#${string}` | ''}` | `/Components/Login${`?${string}` | `#${string}` | ''}` | `/Components/SignUp${`?${string}` | `#${string}` | ''}` | `/Components/SplashScreen${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/Components/DashboardScreen`; params?: Router.UnknownInputParams; } | { pathname: `/Components/ForgotPassword`; params?: Router.UnknownInputParams; } | { pathname: `/Components/Login`; params?: Router.UnknownInputParams; } | { pathname: `/Components/SignUp`; params?: Router.UnknownInputParams; } | { pathname: `/Components/SplashScreen`; params?: Router.UnknownInputParams; };
    }
  }
}
